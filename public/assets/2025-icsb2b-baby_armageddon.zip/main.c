#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void armageddon()
{
  FILE *fp;
  char flag[64];
  fp = fopen("flag.txt", "r");
  if (fp == NULL)
  {
    printf("Error opening file!\n");
    exit(1);
  }
  fgets(flag, sizeof(flag), fp);
  fclose(fp);
  printf("\n[ALERT! Emergency Armageddon Credentials Obtained]\n%s\n", flag);
  exit(0);
}

void question()
{
  char question[128];
  printf("What is your question? ");
  gets(question);
  printf("Just kidding! We are not sending any information to you!\n");
}

int main(int argc, char *argv[]){
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
  setbuf(stderr, NULL);
  question();
  return 0;
}